using System;
using System.Collections.Generic;
using System.Linq;

namespace OrderProcessingSystem.Models
{
    // Requirement 7: Product Class
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }

        public Product(int id, string name, decimal price, string category)
        {
            Id = id;
            Name = name;
            Price = price;
            Category = category;
        }
    }

    // Requirement 1 & 14: Composition (Order "has" OrderItems)
    public class OrderItem
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
        
        // Calculated Property
        public decimal SubTotal => Product.Price * Quantity;

        public OrderItem(Product product, int quantity)
        {
            Product = product;
            Quantity = quantity;
        }
    }

    // Requirement 26: Encapsulation (Customer details)
    public class Customer
    {
        public int Id { get; private set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public Customer(int id, string name, string email)
        {
            Id = id;
            Name = name;
            Email = email;
        }
    }

    // Requirement 9: History Log Entry
    public class StatusLog
    {
        public DateTime Timestamp { get; set; }
        public OrderStatus Status { get; set; }
        public string Notes { get; set; }

        public override string ToString()
        {
            return $"[{Timestamp:HH:mm:ss}] {Status}: {Notes}";
        }
    }

    // Requirement 7: Order (Root Entity)
    public class Order
    {
        public int Id { get; private set; }
        public Customer Customer { get; set; }
        
        // Requirement 15: Generic List for composition
        public List<OrderItem> Items { get; private set; } = new List<OrderItem>();
        
        public OrderStatus Status { get; set; } = OrderStatus.Created;

        // Requirement 9: In-memory history collection
        public List<StatusLog> History { get; private set; } = new List<StatusLog>();

        public Order(int id, Customer customer)
        {
            Id = id;
            Customer = customer;
            AddHistoryLog(OrderStatus.Created, "Order Created");
        }

        public void AddItem(Product p, int qty)
        {
            Items.Add(new OrderItem(p, qty));
        }

        public decimal CalculateTotal()
        {
            return Items.Sum(i => i.SubTotal);
        }

        public void AddHistoryLog(OrderStatus status, string notes)
        {
            History.Add(new StatusLog { Timestamp = DateTime.Now, Status = status, Notes = notes });
        }
    }
}