using System;
using System.Collections.Generic;
using OrderProcessingSystem.Models;

namespace OrderProcessingSystem.Services
{
    public class OrderService
    {
        // Requirement 10: The Delegate Instance
        public OrderStatusHandler OnStatusChanged;

        // Requirement 15: Dictionary for O(1) Lookup
        private Dictionary<int, Order> _orderRepository = new Dictionary<int, Order>();

        public void RegisterOrder(Order order)
        {
            if (!_orderRepository.ContainsKey(order.Id))
            {
                _orderRepository.Add(order.Id, order);
                Console.WriteLine($"[System] Order {order.Id} registered for {order.Customer.Name}.");
            }
        }

        // Requirement 3: Responsibility for changing status
        public bool UpdateStatus(int orderId, OrderStatus newStatus)
        {
            if (!_orderRepository.ContainsKey(orderId))
            {
                Console.WriteLine("Order not found!");
                return false;
            }

            Order order = _orderRepository[orderId];
            OrderStatus oldStatus = order.Status;

            // Requirement 19 & 22: Validation Rules
            if (!IsValidTransition(oldStatus, newStatus))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[ERROR] Cannot change Order {orderId} from {oldStatus} to {newStatus}. Violation of workflow.");
                Console.ResetColor();
                return false;
            }

            // Update State
            order.Status = newStatus;
            order.AddHistoryLog(newStatus, "Status updated via Service");

            // Requirement 10: Invoke Delegate (Multicast)
            if (OnStatusChanged != null)
            {
                OnStatusChanged.Invoke(order, oldStatus, newStatus);
            }

            return true;
        }

        // State Machine Logic
        private bool IsValidTransition(OrderStatus current, OrderStatus next)
        {
            if (current == OrderStatus.Cancelled) return false;
            if (next == OrderStatus.Cancelled) return true;

            // Strict workflow: Created -> Paid -> Processing -> Shipped -> Delivered
            switch (current)
            {
                case OrderStatus.Created: return next == OrderStatus.Paid;
                case OrderStatus.Paid: return next == OrderStatus.Processing;
                case OrderStatus.Processing: return next == OrderStatus.Shipped;
                case OrderStatus.Shipped: return next == OrderStatus.Delivered;
                default: return false;
            }
        }
    }
}