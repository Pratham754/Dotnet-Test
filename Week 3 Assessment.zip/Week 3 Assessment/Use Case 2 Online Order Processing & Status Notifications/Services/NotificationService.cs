using System;
using OrderProcessingSystem.Models;

namespace OrderProcessingSystem.Services
{
    public class NotificationService
    {
        // Subscriber 1: Customer (Requirement 11)
        public void NotifyCustomer(Order order, OrderStatus oldStatus, OrderStatus newStatus)
        {
            Console.WriteLine($"   >>> [Email Service] To: {order.Customer.Email} | Msg: Your order #{order.Id} is now {newStatus}.");
        }

        // Subscriber 2: Logistics (Requirement 11)
        public void NotifyLogistics(Order order, OrderStatus oldStatus, OrderStatus newStatus)
        {
            if (newStatus == OrderStatus.Shipped)
            {
                Console.WriteLine($"   >>> [Logistics API] Dispatching truck for Order #{order.Id}. Total Weight: {order.Items.Count * 2}kg.");
            }
            else if (newStatus == OrderStatus.Delivered)
            {
                Console.WriteLine($"   >>> [Logistics API] Closing ticket for Order #{order.Id}.");
            }
        }
    }
}