﻿using System;
using System.Collections.Generic;
using OrderProcessingSystem.Models;
using OrderProcessingSystem.Services;

namespace OrderProcessingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. Setup Sample Data
            var p1 = new Product(1, "Laptop", 1000m, "Electronics");
            var p2 = new Product(2, "Mouse", 20m, "Electronics");
            var c1 = new Customer(101, "Alice", "alice@test.com");
            var c2 = new Customer(102, "Bob", "bob@test.com");

            // 2. Initialize Services
            OrderService svc = new OrderService();
            NotificationService notifier = new NotificationService();

            // 3. Attach Subscribers (Multicasting)
            svc.OnStatusChanged += notifier.NotifyCustomer;
            svc.OnStatusChanged += notifier.NotifyLogistics;

            // 4. Create and Register Orders
            Order order1 = new Order(5001, c1);
            order1.AddItem(p1, 1);
            order1.AddItem(p2, 2); // 2 Mice
            svc.RegisterOrder(order1);

            Order order2 = new Order(5002, c2);
            order2.AddItem(p1, 1);
            svc.RegisterOrder(order2);

            Console.WriteLine("\n--- Starting Order Processing ---\n");

            // 5. Test Happy Path (Order 1)
            svc.UpdateStatus(5001, OrderStatus.Paid);
            svc.UpdateStatus(5001, OrderStatus.Processing);
            svc.UpdateStatus(5001, OrderStatus.Shipped);

            // 6. Test Invalid Path (Order 2)
            Console.WriteLine("\n--- Testing Invalid Transition (Order 2) ---");
            // Trying to Ship before Paid
            svc.UpdateStatus(5002, OrderStatus.Shipped); 

            // 7. Final Report
            Console.WriteLine("\n" + new string('=', 50));
            Console.WriteLine("FINAL ORDER REPORT");
            Console.WriteLine(new string('=', 50));
            
            PrintOrder(order1);
            PrintOrder(order2);

            Console.ReadKey();
        }

        static void PrintOrder(Order o)
        {
            Console.WriteLine($"\nOrder #{o.Id} | Status: {o.Status} | Total: {o.CalculateTotal():C}");
            Console.WriteLine("History Timeline:");
            foreach (var log in o.History)
            {
                Console.WriteLine($" - {log}");
            }
        }
    }
}